<?php
require_once 'vendor/autoload.php';


$email=urlencode($_POST["email"]);


// These code snippets use an open-source library. http://unirest.io/php
$response = Unirest\Request::get("https://fullcontact.p.mashape.com/v2/person.json?apiKey=fe5b8548d07c57aa&email=".$email,
  array(
    "X-Mashape-Key" => "nftkNK98pqmshVtvzEBvGWCXQn8vp1XJWTejsnNnowzhv2crzB",
    "Accept" => "application/json"
  )
);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Advay Contact Fetcher</title>
	<style type="text/css">
		body{
			font-family: Arial;
			font-size: 12px;
		}

		img{
			width: 150px;
			height: 150px;
		}

	</style>
</head>
<body>
<h1>Welcome to Advay Ads Full Contact Information Fetcher </h1> 

<div style="background-color: black;color: red;">
Name : <?php echo $response->body->contactInfo->fullName ?> <br>
Photo <img src="<?php echo $response->body->photos[0]->url ?>"><hr>
<?php
echo "<pre>";
print_r($response->body);
echo "</pre>";
 
?>
</div>
</body>
</html>
