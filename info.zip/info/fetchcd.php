<?php
require_once 'vendor/autoload.php';


$val=urlencode($_POST["val"]);


// These code snippets use an open-source library. http://unirest.io/php
$response = Unirest\Request::get("https://api.fullcontact.com/v2/company/lookup.json?apiKey=fe5b8548d07c57aa&domain=".$val,
  array(
    "X-Mashape-Key" => "nftkNK98pqmshVtvzEBvGWCXQn8vp1XJWTejsnNnowzhv2crzB",
    "Accept" => "application/json"
  )
);

function startsWith($haystack, $needle)
{
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}

function endsWith($haystack, $needle)
{
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }

    return (substr($haystack, -$length) === $needle);
}
function tableize($in) {
 echo "<table  border=2>";
 foreach($in AS $key => $value) {
  if(is_array($value)) {
   echo "<tr><td>$key:".tableize($value)."</td></tr>";
  } else if(is_object($value) )
  {
      $arr= (array)$value;
      tableize($arr);
  }else
   {

    $visit=''; 
    if($key=="user_id")
    {
      
     // $newval="<a href='getuser.php?id=$value'>$value</a>";
      
      //$value=$newval;
    }
    if(startsWith($value,"http"))
    {

      $newval ="<a href='$value'><img src='$value' width=100px height=100px onerror=this.style.display='none' />$value</a>";
      
      $value=$newval;
    }


   echo "<tr><td>$key</td> <td>$value</td> </tr>";
  }

 }
 echo "</table>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>LeadingEdge Contact Fetcher</title>
	<link rel = "stylesheet" type = "text/css"  href = "style.css" />
  <style type="text/css">
    body{
      background-color: black;
      color: white;
      font-family: Arial;
      font-size: 13px;

    }
    table{
      border-color: green;
      border:4px;

    }
    img{
      background-color: white;
      width: 150px;
      width:150px;
    }
    p{
      font-family: Arial;
      font-style: italic;
      font-size: 
    }
    #jsondata{
      
      text-align: center;
      background-color: black;
      color: green;
      margin: 20px;

    }
    #content{
      width: 95%;
      margin: 40px;
    }
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
  
$(document).ready(function() {
   $("#zoomin").click(function(){
        $("table").animate({
           
            height: '+=10px',
            width: '+=10px'
        });
    });

    $("#zoomout").click(function(){
        $("table").animate({
           
            height: '-=10px',
            width: '-=10px'
        });
    });

});

</script>

	</style>
</head>
<body>
<marquee>This information is 100% valid and correct . </marquee>
<div id="content">
<h1>Welcome to Leadingedge Company Info Fetcher </h1> 
<p> Developed by Sakeat Gandotra </p>
<?php 

// test code
// // sakeat 4-8-2017
//  echo "<pre>";
//  print_r($response->body->website);
//  echo "</pre>";
//  die;
?> 
<p>Company Name : <?php echo $response->body->organization->name ?> </p>
<p>Company Website : <a href="<?php echo $response->body->website ?>" target="_blank"> 
<?php echo $response->body->website ?> </a> </p>
<p>Company Logo : <a href="<?php echo $response->body->website ?>" target="_blank"> <img width="150" height="150" alt="<?php echo $response->body->organization->name ?>" src="<?php echo $response->body->organization->images[0]->url ?>"> <?php echo $response->body->organization->name ?> </a><hr></p>
<div class="datagrid">

<?php

$array=(array)$response->body;

tableize($array);
echo "<br><hr>";
echo "<div id='jsondata'>";
echo "<u>Data in JSON Format</u> <br>";
$data=  json_encode($response->body, JSON_PRETTY_PRINT);
echo "<pre>";
print_r($data);

echo "</pre>";
echo "<div>"

?>
</div>
</div>
</body>
</html>
