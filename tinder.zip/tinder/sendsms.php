<?php 
    include('way2sms-api.php');
    $mobile=$_POST['username'];
    $message=$_POST['message'];

    $client = new WAY2SMSClient();
    $client->login('9620085015', 'snij123');
    $sum= $client->send($mobile, $message);
    echo "<pre>";
    print_r($sum);
    echo "</pre>";
    //Add sleep between requests to make this requests more human like! 
    //A blast of request's may mark the ip as spammer and blocking further requests.
   // sleep(1);
    //echo $client->send('9620085015,9036070550', 'You have reached here . Click on http://advayads.mysouqa.com . Br. Sakeat');
    sleep(1);
    $client->logout();
?>
<meta http-equiv="refresh" content="2;url=sms.php?msg=Message Sent...." />.
<a href="sms.php" > Go Back </a>