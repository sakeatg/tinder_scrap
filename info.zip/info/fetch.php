<?php
require_once 'vendor/autoload.php';


$email=urlencode($_POST["email"]);


// These code snippets use an open-source library. http://unirest.io/php
$response = Unirest\Request::get("https://fullcontact.p.mashape.com/v2/person.json?apiKey=fe5b8548d07c57aa&email=".$email,
  array(
    "X-Mashape-Key" => "nftkNK98pqmshVtvzEBvGWCXQn8vp1XJWTejsnNnowzhv2crzB",
    "Accept" => "application/json"
  )
);

function startsWith($haystack, $needle)
{
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}

function endsWith($haystack, $needle)
{
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }

    return (substr($haystack, -$length) === $needle);
}
function tableize($in) {
 echo "<table  border=2>";
 foreach($in AS $key => $value) {
  if(is_array($value)) {
   echo "<tr><td>$key:".tableize($value)."</td></tr>";
  } else if(is_object($value) )
  {
      $arr= (array)$value;
      tableize($arr);
  }else
   {

    $visit=''; 
    if($key=="user_id")
    {
      
      $newval="<a href='getuser.php?id=$value'>$value</a>";
      
      $value=$newval;
    }
    if(startsWith($value,"http"))
    {

      $newval ="<a href='$value'><img src='$value' width=100px height=100px onerror=this.style.display='none' />$value</a>";
      
      $value=$newval;
    }


   echo "<tr><td>$key</td> <td>$value</td> </tr>";
  }

 }
 echo "</table>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>LeadingEdge Contact Fetcher</title>
	<link rel = "stylesheet" type = "text/css"  href = "style.css" />
  <style type="text/css">
    body{
      background-color: black;
      color: red;
      font-family: Arial;
      font-size: 12px;

    }
    table{
      border-color: red;
      border:4px;
    }

  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
  
$(document).ready(function() {
   $("button").click(function(){
        $("table").animate({
           
            height: '+=10px',
            width: '+=10px'
        });
    });
});

</script>

	</style>
</head>
<body>
<h1>Welcome to Leading Edge Full Contact Information Fetcher </h1> 
<p> Developed by Sakeat Gandotra </p>
Name : <?php echo $response->body->contactInfo->fullName ?> <br>
Photo <img width="150px" height="150px" src="<?php echo $response->body->photos[0]->url ?>"><hr>
<div class="datagrid">

<?php

$array=(array)$response->body;

tableize($array);
echo "<br><hr>";
echo "<pre>";
echo "<u>Data in JSON Format</u> <br>";
$data=  json_encode($response->body, JSON_PRETTY_PRINT);
print_r($data);

echo "</pre>";

?>
</div>
</body>
</html>
