<!DOCTYPE html>
<html>
<head>
	<title>Leadingedge Contact Fetcher</title>
	<link rel = "stylesheet" type = "text/css"  href = "style.css" />
  <style type="text/css">
    body{
      background-color: black;
      color: green;
      font-family: Arial;
      font-size: 12px;

    }
    table{
      border-color: green;
      border:4px;
    }
    img{
      background-color: white;
    }
    p{
      font-family: Arial;
      font-style: italic;
      font-size: 
    }
    #jsondata{
      
      text-align: center;
      background-color: black;
      color: green;
      margin: 20px;

    }
    #content{
      width: 95%;
      margin: 40px;
    }
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
  
$(document).ready(function() {
   $("#zoomin").click(function(){
        $("table").animate({
           
            height: '+=10px',
            width: '+=10px'
        });
    });

    $("#zoomout").click(function(){
        $("table").animate({
           
            height: '-=10px',
            width: '-=10px'
        });
    });

});

</script>

	</style>
</head>
<body>
<marquee>This information is 100% valid and correct . </marquee>
<div id="content">

<h1>Welcome to Leadingedge Company Info Fetcher </h1> 
<p> Developed by Sakeat Gandotra </p>


<form action="fetchcd.php" method="post">

Enter Company Domain to fetch Information <input type="text" name="val" placeholder="facebook.com" value="">
<input type="submit" value="Fetch Data" >
</form>
<marquee>Note: Just Enter the email of the company and get all social information for the company from twitter,facebook,google+ and more...</marquee>
</body>
</html>