#######################################################

 Magic Zoom™
 OpenCart module version v4.3.14 [v1.6.53:v5.2.3]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2017 Magic Toolbox

#######################################################

INSTALLATION:

1. Unzip the file on your computer and FTP the magiczoom folder to your OpenCart directory (on your server), keeping the file and folder structure intact.

2. Go to http://www.yoursite.url/magiczoom/ in your browser > click 'Install' (replace yoursite.url with your domain name).

3. Go to [Admin panel > Extensions > Modules] and install module.

4. If you are using OpenCart 2.x go to [Admin panel > Modifications] and click 'Reftesh' button.

5. Remain on [Admin panel > Extensions > Modules] and click 'Edit' by the Magic Zoom listing and enable module.

6. The demo version is now installed :)

7. Customize the Magic Zoom module through the [Extensions > Modules > Edit] menu in your OpenCart admin panel.

8. To upgrade your version of Magic Zoom (which removes the "Please upgrade" text), buy Magic Zoom and overwrite the catalog/view/javascript/magiczoom.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoom/

