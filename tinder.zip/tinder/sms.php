<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>
      Advay Ads SMS Sender - Sakeat Gandotra
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
   <script type="javascript">
        $(document).ready(function(){
        $('#characterlimit').text('140 Characters limt');
        $('#message').keydown(function () {
            var max = 140;
            var len = $(this).val().length;
            if (len >= max) {
                $('#characterlimit').text('Left 0');
                $('#characterlimit').addClass('test-danger');
                $('#btnSubmit').addClass('disabled');           
            }
            else {
                var ch = max - len;
                $('#characterlimit').text(ch + ' characters left');
                $('#btnSubmit').removeClass('disabled');
                $('#characterlimit').removeClass('test-danger');           
            }
        });   
    });
    </script>
    <style type="text/css">
       body {
    background-color: darkslategrey;
    color: cornflowerblue;
    text-align: center;
}
    </style>
  </head>
  <body>
  <h1>Advay Ads - A New Era Digital Marketing Firm</h1>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div style="margin-top:50px;" class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
                    <div class="panel panel-info" >
                        <div class="panel-heading">
                            <div class="panel-title">Advay Ads Send SMS - @developer : Sakeat Gandotra</div>
                        </div>     
                       <div style="color:red" ><?php echo isset($_GET['msg'])?$_GET['msg']:'';?></div>
<form action="sendsms.php" method="post">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                +91
                                            </span>
                                            <input type="text" class="form-control borderRadius" name="username" value="" placeholder="Enter the Mobile Number">                                        
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="form-group">
                                        <textarea class="form-control input-sm borderRadius " type="textarea" id="message" name="message" placeholder="Message" maxlength="140" rows="7"></textarea>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                                    <span class="help-block">
                                        <p id="characterlimit" class="help-block " style="text-align: left;">140 Chars&nbsp;</p>
                                    </span>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" align="right">
                                    <button class="btn btn-success " id="btnSubmit" name="btnSubmit" type="button" onclick="form.submit()">Send SMS</button>                                        
                                </div>
                            </div>
                            
                            </form>
                             <span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><style type="text/css">.help-block .test-danger{
            color:red;
        }
        .input-sm {
            border-radius: 0 !important;
        }
        .input-group .form-control {
            border-radius: 0;
            box-shadow: none;  
        }
        .form-control{
            box-shadow: none !important;
            border-radius: 0;
        }</style>
 
 
 </span></span>

                        </div>                     
                    </div>  
                </div>    
            </div>
        </div>
    </div>
<script type="text/javascript">
var ZCallbackWidgetLinkId  = '258c729fd536ad19204a94f4b6371a5f';
var ZCallbackWidgetDomain  = 'my.zadarma.com';
(function(){
    var lt = document.createElement('script');
    lt.type ='text/javascript';
    lt.charset = 'utf-8';
    lt.async = true;
    lt.src = 'https://' + ZCallbackWidgetDomain + '/callbackWidget/js/main.min.js?unq='+Math.floor(Math.random(0,1000)*1000);
    var sc = document.getElementsByTagName('script')[0];
    if (sc) sc.parentNode.insertBefore(lt, sc);
    else document.documentElement.firstChild.appendChild(lt);
})();
</script>   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  </body>
</html>