<?php include "header.php" ?>
<?php


echo "<pre>";
$data=$tinder->friends();
$array =  (array) $data;
tableize($array);
//echo array2table($array,true);
echo "</pre>"
?>

<?php include "footer.php" ?>


