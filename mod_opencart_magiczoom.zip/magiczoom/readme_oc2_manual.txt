#######################################################

 Magic Zoom™
 OpenCart module version v4.3.14 [v1.6.53:v5.2.3]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2017 Magic Toolbox

#######################################################

INSTALLATION:

If you use VQmod and if installation using web installer failed, please continue using these instructions below:

1. Copy 'system', 'catalog' and 'admin' folders to your OpenCart directory (on your server), keeping the file and folder structure intact.

2. Open your OpenCart admin panel. Go to: [Extensions > Modifications > Click 'Refresh' button].

3. Go to: [Extensions > Modules > Magic Zoom > Click 'Install'].

4. Enable Magic Zoom™ [Extensions > Modules > Magic Zoom > Edit > Enable/Disable module > Select 'Enable'].

5. The Magic Zoom is now installed!

6. Customize the Magic Zoom™ module through the [Extensions > Modules > Magic Zoom > Edit] menu in your OpenCart admin panel.

7. To upgrade your version of Magic Zoom (which removes the "Please upgrade" text), buy Magic Zoom and overwrite the catalog/view/javascript/magiczoom.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoom/

