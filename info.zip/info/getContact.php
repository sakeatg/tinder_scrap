<!DOCTYPE html>
<html>
<head>
	<title>Leadingedge Contact Fetcher</title>
	<style type="text/css">
		body{
			font-family: Arial;
			font-size: 14px;
			background-color: black;
			color: red;
		}

	</style>
</head>
<body>

<h1> Welcome to Leadingedge Full Contact Information Fetcher </h1>
<p> Developed by Sakeat Gandotra </p>
<form action="fetch.php" method="post">

Enter Email to fetch Information <input type="text" name="email" placeholder="sakeatg@gmail.com" value="">
<input type="submit" value="Fetch Data" >
</form>
<marquee>Note: Just Enter the email of the person and get all social information for the person from twitter,facebook,google+ and more...</marquee>
</body>
</html>