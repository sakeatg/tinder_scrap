<?php include "header.php" ?>
<?php
$data=$tinder->user($_GET['id']);

echo "<pre>";
//$data=$tinder->recommendations();
$array =  (array) $data;
tableize($array);
//echo array2table($array,true);
echo "</pre>"
?>

<?php include "footer.php" ?>


