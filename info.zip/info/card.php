<?php
$url = "https://api.fullcontact.com/v2/cardReader?webhookUrl=http://myDomain.com/myWebhookHandler&verified=medium"
$imageAsBase64 = base64_encode(file_get_contents("/path/to/bizcard.jpg"));
$requestBody = array();
$requestBody['front'] = $imageAsBase64;

$connection = curl_init();
curl_setopt($connection, CURLOPT_URL, $url);
curl_setopt($connection, CURLOPT_RETURNTRANSFER, true);
curl_setopt($connection, CURLOPT_POST, true);
curl_setopt($connection, CURLOPT_POSTFIELDS, json_encode($requestBody));
curl_setopt($connection, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));  

$result = curl_exec($connection);


?>