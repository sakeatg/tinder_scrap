<?php
require_once 'vendor/autoload.php';






$fb_access_token="EAAGm0PX4ZCpsBALYvwvAPCKRyi1bKFcp6LEjFbSNK7lQO2jY9idskvo1nmgb52Rs1ew8H4Ph2RS0LlQFZBHE4u5XlZCsAlf0VfDCLYoZCP2a4ZCNI3PsV4NTqdxWZABiOLNu2r4D7Ul92SIRlOGugBsAIyqPeQWqh0Nz93w0dkNaB91AXZAyjutUoYvh2PRIcPjLIHNoGKgpSbqZAZAQ8Vz2YQkwkOMJxIbkYJSEqGrAbKvjHZBJSNlPqn8xO711NCZBT7hWsPeed5rSAZDZD";



$tinder = new \Pecee\Http\Service\Tinder($fb_id, $fb_access_token);




?>
<!DOCTYPE html>
<html>
<head>
  <title>Tinder Search</title>
  <link rel = "stylesheet" type = "text/css"  href = "style.css" />
  <style type="text/css">
    body{
      background-color: black;
      color: red;
      font-family: Arial;
      font-size: 12px;

    }
    table{
      border-color: red;
      border:4px;
    }

  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
  
$(document).ready(function() {
   $("button").click(function(){
        $("table").animate({
           
            height: '+=10px',
            width: '+=10px'
        });
    });
});

</script>

</head>
<body>
<h1> Tinder Search App </h1>
<h3>Developed by Sakeat Gandotra </h3>
<a href="index.php">Get Recomendations on Tinder</a>
| <a href="getfriends.php">Get Friends on Tinder</a>
| <a href="myinfo.php">Get My Profile</a>

<button>Zoom+++</button>
<div class="datagrid">
<?php
//$data=$tinder->user("597b8a617f169c277f2de8c8");


function startsWith($haystack, $needle)
{
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}

function endsWith($haystack, $needle)
{
    $length = strlen($needle);
    if ($length == 0) {
        return true;
    }

    return (substr($haystack, -$length) === $needle);
}
function tableize($in) {
 echo "<table  border=2>";
 foreach($in AS $key => $value) {
  if(is_array($value)) {
   echo "<tr><td>$key:".tableize($value)."</td></tr>";
  } else if(is_object($value) )
  {
      $arr= (array)$value;
      tableize($arr);
  }else
   {

    $visit=''; 
    if($key=="user_id")
    {
      
      $newval="<a href='getuser.php?id=$value'>$value</a>";
      
      $value=$newval;
    }
    if(startsWith($value,"http"))
    {

      $newval ="<a href='$value'><img src='$value' width=100px height=100px /></a>";
      $urlp=parse_url($value);
      $tinderid=$urlp["path"];
      $tinderid=substr($tinderid, 1,24);
      $visit="<a href='getuser.php?id=$tinderid'>$tinderid</a>";

      $value=$newval;
    }


   echo "<tr><td>$key</td> <td>$value</td> <td>$visit </td></tr>";
  }

 }
 echo "</table>";
}
?>